importent links: 
	1. https://dzone.com/articles/spring-boot-restful-api-documentation-with-swagger
	2. https://www.baeldung.com/swagger-2-documentation-for-spring-rest-api

