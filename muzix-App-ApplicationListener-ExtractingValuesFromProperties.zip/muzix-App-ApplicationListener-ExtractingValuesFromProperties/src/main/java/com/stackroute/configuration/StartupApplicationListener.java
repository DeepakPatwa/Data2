package com.stackroute.configuration;

import com.stackroute.domain.MusicTrack;
import com.stackroute.repository.MusicRepository;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;


@Component
@PropertySource(value = "startup.properties")
public class StartupApplicationListener implements ApplicationListener<ContextRefreshedEvent>{

    private MusicRepository musicRepository;

    private static final Logger log = Logger.getLogger(StartupApplicationListener.class);

    @Autowired
    public StartupApplicationListener(MusicRepository musicRepository) {
        this.musicRepository=musicRepository;
    }


    @Value("${firstName}")
    private String name1;

    @Value("${firstComment}")
    private String comment1;

    @Autowired
    private Environment environment;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {

        log.info("Entering Data On Start using ApplicationListener");

        MusicTrack musicTrack1= new MusicTrack();
        musicTrack1.setName(name1);
        musicTrack1.setComment(comment1);
        musicRepository.save(musicTrack1);

        MusicTrack musicTrack2=new MusicTrack();
        musicTrack2.setName(environment.getProperty("secondName"));
        musicTrack2.setComment(environment.getProperty("secondComment"));
        musicRepository.save(musicTrack2);

        log.info("Initial data entered using ApplicationListener");
    }
}
