package com.stackroute.configuration;

import com.stackroute.domain.MusicTrack;
import com.stackroute.repository.MusicRepository;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;


@Component
public class StartupApplicationListener implements ApplicationListener<ContextRefreshedEvent>{

    private MusicRepository musicRepository;

    private static final Logger log = Logger.getLogger(StartupApplicationListener.class);

    @Autowired
    public StartupApplicationListener(MusicRepository musicRepository) {
        this.musicRepository=musicRepository;
    }


    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {

        log.info("Entering Data On Start using ApplicationListener");

        MusicTrack musicTrack1= new MusicTrack();
        musicTrack1.setId(1);
        musicTrack1.setName("Chal wha jate hai");
        musicTrack1.setComment("thik thak song");
        musicRepository.save(musicTrack1);

        MusicTrack musicTrack2=new MusicTrack();
        musicTrack2.setId(2);
        musicTrack2.setName("chal chaiya chaiya");
        musicTrack2.setComment("hit song");
        musicRepository.save(musicTrack2);

        log.info("Initial data entered using ApplicationListener");
    }
}
