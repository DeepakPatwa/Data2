package com.stackroute.configuration;

import com.stackroute.domain.MusicTrack;
import com.stackroute.repository.MusicRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class StartupCommandLineRunner implements CommandLineRunner {

    MusicRepository musicRepository;

    public static final Logger log = LoggerFactory.getLogger(StartupCommandLineRunner.class);

    @Autowired
    public StartupCommandLineRunner(MusicRepository musicRepository) {
        this.musicRepository = musicRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        log.info("Entering Data On Start using CommandLineRunner");

        musicRepository.save(new MusicTrack(2,"I love U","good song"));
        musicRepository.save(new MusicTrack(3,"Tera yar hu main", "fadu song"));

        log.info("Initial data entered using CommandLineRunner");
    }
}
