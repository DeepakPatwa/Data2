package com.stackroute.service;
//////////////////////////////////////////////////// Change it to MusicServiceImpl ///////////////////////
import com.stackroute.domain.MusicTrack;
import com.stackroute.exceptions.TrackDoesNotExists;
import com.stackroute.exceptions.TrackAlreadyExistsException;
import com.stackroute.repository.MusicRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MusicDBServices implements MusicServices{


    private MusicRepository musicRepository;

    @Autowired//if there is only one constructor then spring by defult do autowire and we need not to anotate Autowire
    public MusicDBServices(MusicRepository musicRepository) {
        this.musicRepository= musicRepository;
    }


    //remove set
    public void setTrackRepository(MusicRepository musicRepository) {

        this.musicRepository = musicRepository;
    }

    // add comments
    // Add readme also
    // no need to write public cuz by default methods are public only
    public MusicTrack saveTrack(MusicTrack musicTrack) throws TrackAlreadyExistsException
    {
        if(musicRepository.existsById(musicTrack.getId()))
        {
            throw new TrackAlreadyExistsException("User Already Exists");
        }

        MusicTrack musicTrack1=musicRepository.save(musicTrack);

        if(musicTrack1==null)
            throw new TrackAlreadyExistsException("User Already Exists");

        return musicTrack1;
    }

    public List<MusicTrack> getAllTracks() {
        List<MusicTrack> trackList = (List<MusicTrack>)musicRepository.findAll();
        return trackList;
    }

    public MusicTrack updateTrack(int id, String comment) throws TrackDoesNotExists{
        if(!musicRepository.existsById(id))
        {
            throw new TrackDoesNotExists("no such Track exists");
        }

        MusicTrack musicTrack=musicRepository.findById(id).get();
        if (musicTrack==null)
        {
            throw new TrackDoesNotExists("no such Track exists");
        }
        musicTrack.setComment(comment);

        return musicRepository.save(musicTrack);
    }

//    public MusicTrack updateTrack(MusicTrack musicTrack) throws TrackDoesNotExists {
//        if(!musicRepository.existsById(musicTrack.getId()))
//        {
//            throw new TrackDoesNotExists("no such Track exists");
//        }
//        MusicTrack musicTrack1=musicRepository.save(musicTrack);
//        if (musicTrack1==null)
//        {
//            throw new TrackDoesNotExists("no such Track exists");
//        }
//        return musicTrack1;
//    }

    public void deleteTrack(int id) throws TrackDoesNotExists{

        if(musicRepository.existsById(id)==false)
        {
            throw new TrackDoesNotExists("no such Track exists");
        }

        musicRepository.deleteById(id);
    }
}
